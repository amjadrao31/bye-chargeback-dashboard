=== ByeChargeBack Custom Dashboard ===
Contributors: byechargeback
Tags: dashboard, chargeback, credits, billing
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.1
License: GPLv2 or later

Custom user dashboard with signup flow, credits pricing, alerts, billing, and admin-configurable links for ByeChargeBack.

== Installation ==

1. Upload the `bye-chargeback-dashboard` folder to `/wp-content/plugins/`.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. On activation, pages are created automatically (Get Started, Sign In, Dashboard).
4. Go to **BCB Dashboard** in the admin menu and configure branding, pricing, and links.
5. Add `[bcb_home_button]` to your homepage.

== Shortcodes ==

* `[bcb_home_button]` — Homepage CTA button (links to Get Started page)
* `[bcb_get_started]` — 3-step signup flow (intro → email → check inbox)
* `[bcb_sign_in]` — Sign-in screen (linked from welcome email)
* `[bcb_dashboard]` — Main dashboard (login required)

== Default Brand ==

Brand name: ByeChargeBack
Brand email: contact@ByeChargeBack.com
