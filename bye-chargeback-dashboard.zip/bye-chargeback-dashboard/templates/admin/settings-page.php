<?php
/**
 * Admin settings page template.
 *
 * @var array $settings
 * @var array $pages
 * @var array $pricing
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;

if ( isset( $_GET['bcb-settings-saved'] ) ) {
	add_settings_error(
		'bcb_messages',
		'bcb_saved',
		__( 'Settings saved successfully.', 'bye-chargeback-dashboard' ),
		'success'
	);
}

settings_errors( 'bcb_messages' );
?>
<div class="wrap bcb-admin-wrap">
	<h1><?php esc_html_e( 'ByeChargeBack Dashboard Settings', 'bye-chargeback-dashboard' ); ?></h1>

	<p class="description">
		<?php esc_html_e( 'Configure branding, pricing links, discount, and dashboard content.', 'bye-chargeback-dashboard' ); ?>
		<?php if ( 'local' === wp_get_environment_type() ) : ?>
			<br><strong><?php esc_html_e( 'Local dev:', 'bye-chargeback-dashboard' ); ?></strong>
			<?php esc_html_e( 'Sign-in emails are captured in MailHog. Open your Local site → Tools → MailHog.', 'bye-chargeback-dashboard' ); ?>
		<?php endif; ?>
	</p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin.php?page=bcb-dashboard-settings' ) ); ?>">
		<?php wp_nonce_field( 'bcb_save_settings' ); ?>

		<div class="bcb-admin-grid">
			<div class="bcb-admin-card">
				<h2><?php esc_html_e( 'Brand', 'bye-chargeback-dashboard' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><label for="bcb_brand_name"><?php esc_html_e( 'Brand Name', 'bye-chargeback-dashboard' ); ?></label></th>
						<td><input type="text" id="bcb_brand_name" name="bcb[brand_name]" value="<?php echo esc_attr( $settings['brand_name'] ); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th><label for="bcb_brand_email"><?php esc_html_e( 'Brand Email', 'bye-chargeback-dashboard' ); ?></label></th>
						<td><input type="email" id="bcb_brand_email" name="bcb[brand_email]" value="<?php echo esc_attr( $settings['brand_email'] ); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th><label for="bcb_brand_logo"><?php esc_html_e( 'Brand Logo', 'bye-chargeback-dashboard' ); ?></label></th>
						<td>
							<input type="url" id="bcb_brand_logo" name="bcb[brand_logo_url]" value="<?php echo esc_url( $settings['brand_logo_url'] ); ?>" class="regular-text bcb-logo-url">
							<button type="button" class="button bcb-upload-logo"><?php esc_html_e( 'Upload Logo', 'bye-chargeback-dashboard' ); ?></button>
							<?php if ( ! empty( $settings['brand_logo_url'] ) ) : ?>
								<p><img src="<?php echo esc_url( $settings['brand_logo_url'] ); ?>" alt="" class="bcb-logo-preview"></p>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<th><label for="bcb_logout_url"><?php esc_html_e( 'Logout Redirect URL', 'bye-chargeback-dashboard' ); ?></label></th>
						<td><input type="url" id="bcb_logout_url" name="bcb[logout_redirect_url]" value="<?php echo esc_url( $settings['logout_redirect_url'] ); ?>" class="regular-text"></td>
					</tr>
				</table>
			</div>

			<div class="bcb-admin-card">
				<h2><?php esc_html_e( 'Pages & Shortcodes', 'bye-chargeback-dashboard' ); ?></h2>
				<p class="description"><?php esc_html_e( 'Create WordPress pages and add these shortcodes:', 'bye-chargeback-dashboard' ); ?></p>
				<ul class="bcb-shortcode-list">
					<li><code>[bcb_home_button]</code> — <?php esc_html_e( 'Homepage CTA button (links to Get Started)', 'bye-chargeback-dashboard' ); ?></li>
					<li><code>[bcb_get_started]</code> — <?php esc_html_e( '3-step signup flow', 'bye-chargeback-dashboard' ); ?></li>
					<li><code>[bcb_sign_in]</code> — <?php esc_html_e( 'Sign-in screen (linked from email)', 'bye-chargeback-dashboard' ); ?></li>
					<li><code>[bcb_dashboard]</code> — <?php esc_html_e( 'Main dashboard', 'bye-chargeback-dashboard' ); ?></li>
				</ul>
				<table class="form-table">
					<tr>
						<th><label for="bcb_get_started_page"><?php esc_html_e( 'Get Started Page', 'bye-chargeback-dashboard' ); ?></label></th>
						<td>
							<select id="bcb_get_started_page" name="bcb[get_started_page_id]">
								<option value="0"><?php esc_html_e( '— Select —', 'bye-chargeback-dashboard' ); ?></option>
								<?php foreach ( $pages as $page ) : ?>
									<option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( $settings['get_started_page_id'], $page->ID ); ?>><?php echo esc_html( $page->post_title ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bcb_sign_in_page"><?php esc_html_e( 'Sign In Page', 'bye-chargeback-dashboard' ); ?></label></th>
						<td>
							<select id="bcb_sign_in_page" name="bcb[sign_in_page_id]">
								<option value="0"><?php esc_html_e( '— Select —', 'bye-chargeback-dashboard' ); ?></option>
								<?php foreach ( $pages as $page ) : ?>
									<option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( $settings['sign_in_page_id'], $page->ID ); ?>><?php echo esc_html( $page->post_title ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th><label for="bcb_dashboard_page"><?php esc_html_e( 'Dashboard Page', 'bye-chargeback-dashboard' ); ?></label></th>
						<td>
							<select id="bcb_dashboard_page" name="bcb[dashboard_page_id]">
								<option value="0"><?php esc_html_e( '— Select —', 'bye-chargeback-dashboard' ); ?></option>
								<?php foreach ( $pages as $page ) : ?>
									<option value="<?php echo esc_attr( $page->ID ); ?>" <?php selected( $settings['dashboard_page_id'], $page->ID ); ?>><?php echo esc_html( $page->post_title ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
				</table>
			</div>

			<div class="bcb-admin-card">
				<h2><?php esc_html_e( 'Highlight Colors (Rules / Tooltips)', 'bye-chargeback-dashboard' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><label for="bcb_highlight_color"><?php esc_html_e( 'Text Color', 'bye-chargeback-dashboard' ); ?></label></th>
						<td><input type="color" id="bcb_highlight_color" name="bcb[rule_highlight_color]" value="<?php echo esc_attr( $settings['rule_highlight_color'] ); ?>"></td>
					</tr>
					<tr>
						<th><label for="bcb_highlight_bg"><?php esc_html_e( 'Background Color', 'bye-chargeback-dashboard' ); ?></label></th>
						<td><input type="color" id="bcb_highlight_bg" name="bcb[rule_highlight_bg]" value="<?php echo esc_attr( $settings['rule_highlight_bg'] ); ?>"></td>
					</tr>
				</table>
			</div>

			<div class="bcb-admin-card bcb-admin-card-wide">
				<h2><?php esc_html_e( 'Credits Modal (+ Credits)', 'bye-chargeback-dashboard' ); ?></h2>
				<table class="form-table">
					<tr>
						<th><label for="bcb_credits_headline"><?php esc_html_e( 'Headline', 'bye-chargeback-dashboard' ); ?></label></th>
						<td><input type="text" id="bcb_credits_headline" name="bcb[credits_headline]" value="<?php echo esc_attr( $settings['credits_headline'] ); ?>" class="large-text"></td>
					</tr>
					<tr>
						<th><?php esc_html_e( 'Benefits', 'bye-chargeback-dashboard' ); ?></th>
						<td>
							<?php foreach ( $settings['credits_benefits'] as $index => $benefit ) : ?>
								<p><input type="text" name="bcb[credits_benefits][<?php echo esc_attr( $index ); ?>]" value="<?php echo esc_attr( $benefit ); ?>" class="large-text"></p>
							<?php endforeach; ?>
						</td>
					</tr>
					<tr>
						<th><label for="bcb_discount_code"><?php esc_html_e( 'Discount Code', 'bye-chargeback-dashboard' ); ?></label></th>
						<td><input type="text" id="bcb_discount_code" name="bcb[discount_code]" value="<?php echo esc_attr( $settings['discount_code'] ); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th><label for="bcb_promo_banner"><?php esc_html_e( 'Promo Banner Text', 'bye-chargeback-dashboard' ); ?></label></th>
						<td>
							<input type="text" id="bcb_promo_banner" name="bcb[promo_banner_text]" value="<?php echo esc_attr( $settings['promo_banner_text'] ); ?>" class="large-text">
							<p class="description"><?php esc_html_e( 'Use {code} and {discount} placeholders.', 'bye-chargeback-dashboard' ); ?></p>
						</td>
					</tr>
					<tr>
						<th><label for="bcb_discount"><?php esc_html_e( 'Discount (%)', 'bye-chargeback-dashboard' ); ?></label></th>
						<td>
							<input type="number" id="bcb_discount" name="bcb[discount_percent]" value="<?php echo esc_attr( $settings['discount_percent'] ); ?>" min="0" max="100" step="0.1" class="small-text">
							<p class="description"><?php esc_html_e( 'Get Deal toggles discounted prices and deal checkout links.', 'bye-chargeback-dashboard' ); ?></p>
						</td>
					</tr>
				</table>

				<div class="bcb-pricing-scroll">
				<table class="widefat bcb-pricing-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Transactions label', 'bye-chargeback-dashboard' ); ?></th>
							<th><?php esc_html_e( 'Price (€)', 'bye-chargeback-dashboard' ); ?></th>
							<th><?php esc_html_e( 'Deal Price', 'bye-chargeback-dashboard' ); ?></th>
							<th><?php esc_html_e( 'Buy Plan Link', 'bye-chargeback-dashboard' ); ?></th>
							<th><?php esc_html_e( 'Get Deal Link', 'bye-chargeback-dashboard' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $settings['pricing'] as $index => $tier ) :
							$plan_num = $index + 1;
							$preview  = $pricing[ $index ] ?? null;
							?>
							<tr>
								<td>
									<input type="text" name="bcb[pricing][<?php echo esc_attr( $index ); ?>][transactions]" value="<?php echo esc_attr( $tier['transactions'] ?? '' ); ?>" class="large-text">
									<input type="hidden" name="bcb[pricing][<?php echo esc_attr( $index ); ?>][label]" value="<?php echo esc_attr( $tier['label'] ?? '' ); ?>">
								</td>
								<td>
									<input type="number" name="bcb[pricing][<?php echo esc_attr( $index ); ?>][price]" value="<?php echo esc_attr( $tier['price'] ); ?>" min="0" step="0.01" class="small-text">
								</td>
								<td><strong><?php echo esc_html( $preview ? $preview['discounted'] . '€' : '—' ); ?></strong></td>
								<td><input type="url" name="bcb[links][plan_<?php echo esc_attr( $plan_num ); ?>_standard]" value="<?php echo esc_url( $settings['links'][ "plan_{$plan_num}_standard" ] ?? '' ); ?>" class="large-text"></td>
								<td><input type="url" name="bcb[links][plan_<?php echo esc_attr( $plan_num ); ?>_deal]" value="<?php echo esc_url( $settings['links'][ "plan_{$plan_num}_deal" ] ?? '' ); ?>" class="large-text"></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				</div>
			</div>

			<div class="bcb-admin-card bcb-admin-card-wide">
				<h2><?php esc_html_e( 'Dashboard Tooltips', 'bye-chargeback-dashboard' ); ?></h2>
				<div id="bcb-tooltips">
					<?php foreach ( $settings['tooltip_rules'] as $index => $rule ) : ?>
						<div class="bcb-repeat-row">
							<input type="text" name="bcb[tooltip_rules][<?php echo esc_attr( $index ); ?>][label]" value="<?php echo esc_attr( $rule['label'] ); ?>" placeholder="<?php esc_attr_e( 'Label', 'bye-chargeback-dashboard' ); ?>" class="regular-text">
							<textarea name="bcb[tooltip_rules][<?php echo esc_attr( $index ); ?>][text]" rows="2" class="large-text" placeholder="<?php esc_attr_e( 'Tooltip text', 'bye-chargeback-dashboard' ); ?>"><?php echo esc_textarea( $rule['text'] ); ?></textarea>
						</div>
					<?php endforeach; ?>
				</div>
			</div>

			<div class="bcb-admin-card">
				<h2><?php esc_html_e( 'Protect Account Errors', 'bye-chargeback-dashboard' ); ?></h2>
				<?php foreach ( $settings['protect_account_errors'] as $index => $error ) : ?>
					<p><input type="text" name="bcb[protect_account_errors][<?php echo esc_attr( $index ); ?>]" value="<?php echo esc_attr( $error ); ?>" class="large-text"></p>
				<?php endforeach; ?>
			</div>

			<div class="bcb-admin-card">
				<h2><?php esc_html_e( 'Billing Error Message', 'bye-chargeback-dashboard' ); ?></h2>
				<textarea name="bcb[billing_error_message]" rows="3" class="large-text"><?php echo esc_textarea( $settings['billing_error_message'] ); ?></textarea>
			</div>

			<div class="bcb-admin-card">
				<h2><?php esc_html_e( 'Dispute Prevention Tips', 'bye-chargeback-dashboard' ); ?></h2>
				<?php foreach ( $settings['dispute_tips'] as $index => $tip ) : ?>
					<p><textarea name="bcb[dispute_tips][<?php echo esc_attr( $index ); ?>]" rows="2" class="large-text"><?php echo esc_textarea( $tip ); ?></textarea></p>
				<?php endforeach; ?>
			</div>
		</div>

		<p class="submit">
			<button type="submit" name="bcb_save_settings" value="1" class="button button-primary button-large"><?php esc_html_e( 'Save Settings', 'bye-chargeback-dashboard' ); ?></button>
		</p>
	</form>
</div>
