<?php
/**
 * Credits pricing table (matches document screenshot layout).
 *
 * @var array $vars
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="bcb-pricing-table-wrap" data-pricing-table>
	<table class="bcb-pricing-table">
		<tbody>
			<?php foreach ( $vars['pricing'] as $tier ) :
				$plan_index    = $tier['index'];
				$standard_link = $vars['links'][ $plan_index ]['standard'] ?? '';
				$deal_link     = $vars['links'][ $plan_index ]['deal'] ?? $standard_link;
				?>
				<tr data-plan="<?php echo esc_attr( $plan_index ); ?>">
					<td class="bcb-pt-transactions"><?php echo esc_html( $tier['transactions'] ); ?></td>
					<td class="bcb-pt-price">
						<span class="bcb-price-standard"><?php echo esc_html( $tier['price'] . $tier['currency'] ); ?></span>
						<span class="bcb-price-deal" hidden><?php echo esc_html( $tier['discounted'] . $tier['currency'] ); ?></span>
					</td>
					<td class="bcb-pt-action">
						<?php if ( ! empty( $standard_link ) ) : ?>
							<a href="<?php echo esc_url( $standard_link ); ?>"
								class="bcb-btn bcb-btn-buy bcb-buy-plan"
								data-link-standard="<?php echo esc_url( $standard_link ); ?>"
								data-link-deal="<?php echo esc_url( $deal_link ); ?>"
								target="_blank"
								rel="noopener noreferrer"><?php esc_html_e( 'Buy Plan', 'bye-chargeback-dashboard' ); ?></a>
						<?php else : ?>
							<button type="button" class="bcb-btn bcb-btn-buy" disabled><?php esc_html_e( 'Buy Plan', 'bye-chargeback-dashboard' ); ?></button>
						<?php endif; ?>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>
