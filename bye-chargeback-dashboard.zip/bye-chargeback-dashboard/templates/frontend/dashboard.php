<?php

/**

 * Main dashboard — ByeDispute-style layout with navy palette.

 *

 * @var array   $vars

 * @var WP_User $user

 * @var int     $credits

 *

 * @package ByeChargeBack

 */



defined( 'ABSPATH' ) || exit;



$credits = isset( $credits ) ? (int) $credits : (int) ( $vars['credits'] ?? 0 );

$user    = isset( $user ) ? $user : ( $vars['user'] ?? wp_get_current_user() );



$style_vars = sprintf(

	'--bcb-highlight-color:%1$s;--bcb-highlight-bg:%2$s;',

	esc_attr( $vars['highlight_color'] ),

	esc_attr( $vars['highlight_bg'] )

);

$tips_unlocked = $credits > 0;

$avatar_letter = strtoupper( substr( $user->display_name ?: $user->user_login, 0, 1 ) );
$protection_rules = ( ! empty( $vars['protection_rules'] ) && is_array( $vars['protection_rules'] ) )
	? $vars['protection_rules']
	: array(
		array(
			'condition' => 'payment with suspicious email',
			'action'    => 'send email alert',
		),
	);
?>

<div class="bcb-wrap bcb-dashboard" style="<?php echo esc_attr( $style_vars ); ?>" data-dashboard>

	<header class="bcb-topbar">

		<div class="bcb-topbar-left">

			<div class="bcb-account-menu" data-account-menu>

				<button type="button" class="bcb-account-trigger" data-toggle="account" aria-expanded="false" aria-label="<?php esc_attr_e( 'Account menu', 'bye-chargeback-dashboard' ); ?>">

					<span class="bcb-avatar"><?php echo esc_html( $avatar_letter ); ?></span>

					<span class="bcb-account-label"><?php esc_html_e( 'Account', 'bye-chargeback-dashboard' ); ?></span>

					<svg class="bcb-account-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>

				</button>

				<div class="bcb-account-dropdown" hidden>

					<button type="button" data-view="billing"><?php esc_html_e( 'Billing', 'bye-chargeback-dashboard' ); ?></button>

					<button type="button" data-view="overview"><?php esc_html_e( 'Account Settings', 'bye-chargeback-dashboard' ); ?></button>

					<button type="button" data-open="credits"><?php esc_html_e( 'Buy Credits', 'bye-chargeback-dashboard' ); ?></button>

					<hr>

					<a class="bcb-logout" href="<?php echo esc_url( $vars['logout_url'] ); ?>"><?php esc_html_e( 'Log out', 'bye-chargeback-dashboard' ); ?></a>

				</div>

			</div>

		</div>



		<div class="bcb-topbar-right">

			<button type="button" class="bcb-btn-credits" data-open="credits">

				<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>

				<?php esc_html_e( 'Credits', 'bye-chargeback-dashboard' ); ?>

			</button>



			<div class="bcb-icon-group">

				<button type="button" class="bcb-icon-btn" data-open="alerts" aria-label="<?php esc_attr_e( 'Alerts', 'bye-chargeback-dashboard' ); ?>">

					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>

				</button>



				<span class="bcb-icon-wrap">

					<button type="button" class="bcb-icon-btn" data-open="dispute-tips" aria-label="<?php esc_attr_e( 'Dispute prevention tips', 'bye-chargeback-dashboard' ); ?>">

						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M9 18h6"/><path d="M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7V17h8v-2.3A7 7 0 0 0 12 2z"/></svg>

					</button>

					<span class="bcb-floating-tip"><?php esc_html_e( 'Dispute prevention tips', 'bye-chargeback-dashboard' ); ?></span>

				</span>



				<a class="bcb-icon-btn" href="<?php echo esc_url( $vars['support_mailto'] ); ?>" aria-label="<?php esc_attr_e( 'Talk to support', 'bye-chargeback-dashboard' ); ?>">

					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>

				</a>

			</div>

		</div>

	</header>



	<main class="bcb-main-area">

		<section class="bcb-panel is-active" data-panel="overview">

			<div class="bcb-main-card">

				<h1 class="bcb-account-title"><?php echo esc_html( $vars['dashboard_account_title'] ); ?></h1>



				<div class="bcb-rules-builder">

					<?php foreach ( $protection_rules as $rule ) : ?>

						<div class="bcb-rule-row">

							<div class="bcb-rule-content">

								<span class="bcb-rule-keyword"><?php esc_html_e( 'When', 'bye-chargeback-dashboard' ); ?></span>

								<span class="bcb-rule-pill bcb-rule-condition"><?php echo esc_html( $rule['condition'] ); ?></span>

								<span class="bcb-rule-keyword"><?php esc_html_e( 'then', 'bye-chargeback-dashboard' ); ?></span>

								<span class="bcb-rule-pill bcb-rule-action"><?php echo esc_html( $rule['action'] ); ?></span>

							</div>

							<div class="bcb-rule-reorder" aria-hidden="true">

								<button type="button" class="bcb-rule-sort" tabindex="-1" disabled>

									<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M18 15l-6-6-6 6"/></svg>

								</button>

								<button type="button" class="bcb-rule-sort" tabindex="-1" disabled>

									<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M6 9l6 6 6-6"/></svg>

								</button>

							</div>

						</div>

					<?php endforeach; ?>



					<button type="button" class="bcb-btn-add-rule" disabled>

						<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>

						<?php esc_html_e( 'Rule', 'bye-chargeback-dashboard' ); ?>

					</button>

				</div>



				<div class="bcb-protect-errors" data-protect-errors hidden></div>



				<button type="button" class="bcb-btn bcb-btn-protect bcb-btn-block" data-protect-account><?php esc_html_e( 'Protect Account', 'bye-chargeback-dashboard' ); ?></button>



				<?php if ( $credits <= 0 ) : ?>

					<p class="bcb-credits-warning"><?php echo esc_html( $vars['credits_required_message'] ); ?></p>

				<?php else : ?>

					<p class="bcb-credits-status"><?php esc_html_e( 'Credits remaining:', 'bye-chargeback-dashboard' ); ?> <strong><?php echo esc_html( $credits ); ?></strong></p>

				<?php endif; ?>

			</div>

		</section>



		<section class="bcb-panel" data-panel="billing" hidden>

			<div class="bcb-main-card">

				<h1><?php esc_html_e( 'Billing', 'bye-chargeback-dashboard' ); ?></h1>

				<div class="bcb-alert bcb-alert-error">

					<p><?php echo esc_html( $vars['billing_error'] ); ?></p>

				</div>

				<a href="<?php echo esc_url( $vars['support_mailto'] ); ?>" class="bcb-btn bcb-btn-buy"><?php esc_html_e( 'Contact Support', 'bye-chargeback-dashboard' ); ?></a>

			</div>

		</section>

	</main>



	<!-- + Credits modal -->

	<div class="bcb-modal bcb-modal-credits" data-modal="credits" hidden>

		<div class="bcb-modal-backdrop" data-close></div>

		<div class="bcb-credits-sheet">

			<button type="button" class="bcb-modal-close" data-close aria-label="<?php esc_attr_e( 'Close', 'bye-chargeback-dashboard' ); ?>">&times;</button>



			<h2 class="bcb-credits-title"><?php echo esc_html( $vars['credits_headline'] ); ?></h2>



			<ul class="bcb-credits-benefits">

				<?php foreach ( $vars['credits_benefits'] as $benefit ) : ?>

					<li><?php echo esc_html( $benefit ); ?></li>

				<?php endforeach; ?>

			</ul>



			<div class="bcb-promo-bar">

				<span><?php echo esc_html( $vars['promo_banner'] ); ?></span>

				<button type="button" class="bcb-btn bcb-btn-get-deal" data-deal-toggle><?php esc_html_e( 'Get Deal', 'bye-chargeback-dashboard' ); ?></button>

			</div>



			<?php include BCB_PLUGIN_DIR . 'templates/frontend/partials/pricing-table.php'; ?>



			<div class="bcb-faq">

				<span class="bcb-faq-label"><?php esc_html_e( 'FAQ', 'bye-chargeback-dashboard' ); ?></span>

				<h3><?php esc_html_e( 'Frequently Asked Questions', 'bye-chargeback-dashboard' ); ?></h3>

				<div class="bcb-faq-list">

					<?php foreach ( $vars['faq_items'] as $faq ) : ?>

						<details class="bcb-faq-item">

							<summary><?php echo esc_html( $faq['question'] ); ?></summary>

							<p><?php echo esc_html( $faq['answer'] ); ?></p>

						</details>

					<?php endforeach; ?>

				</div>

			</div>



			<div class="bcb-testimonial">

				<div class="bcb-testimonial-avatar" aria-hidden="true"></div>

				<blockquote>

					<p><?php echo esc_html( $vars['testimonial']['quote'] ); ?></p>

					<cite><?php echo esc_html( $vars['testimonial']['name'] ); ?> <span><?php echo esc_html( $vars['testimonial']['handle'] ); ?></span></cite>

				</blockquote>

			</div>

		</div>

	</div>



	<!-- Dispute tips dropdown -->

	<div class="bcb-popover" data-modal="dispute-tips" hidden>

		<div class="bcb-popover-card">

			<h3><?php echo esc_html( $vars['dispute_tips_title'] ); ?></h3>

			<div class="bcb-tips-body<?php echo $tips_unlocked ? '' : ' is-locked'; ?>">

				<ul class="bcb-tips-list">

					<?php foreach ( $vars['dispute_tips'] as $tip ) : ?>

						<li><?php echo esc_html( $tip ); ?></li>

					<?php endforeach; ?>

				</ul>

				<?php if ( ! $tips_unlocked ) : ?>

					<div class="bcb-tips-lock">

						<p><?php echo esc_html( $vars['dispute_tips_unlock'] ); ?></p>

						<button type="button" class="bcb-btn-credits" data-open="credits" data-close-popover><?php esc_html_e( '+ Credits', 'bye-chargeback-dashboard' ); ?></button>

					</div>

				<?php endif; ?>

			</div>

		</div>

	</div>



	<!-- Alerts popover -->

	<div class="bcb-popover" data-modal="alerts" hidden>

		<div class="bcb-popover-card">

			<h3><?php esc_html_e( 'Alerts', 'bye-chargeback-dashboard' ); ?></h3>

			<ul class="bcb-alerts-list">

				<li><?php esc_html_e( 'Protection is inactive — add credits to enable monitoring.', 'bye-chargeback-dashboard' ); ?></li>

				<li><?php esc_html_e( 'Billing details need to be updated.', 'bye-chargeback-dashboard' ); ?></li>

				<li><?php esc_html_e( 'New dispute prevention tips are available.', 'bye-chargeback-dashboard' ); ?></li>

			</ul>

		</div>

	</div>



	<div class="bcb-tooltip-popup" data-tooltip-popup hidden>

		<strong data-tooltip-title></strong>

		<p data-tooltip-text></p>

	</div>

</div>

