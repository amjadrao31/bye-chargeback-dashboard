<?php
/**
 * Sign-in screen (doc page 2: after clicking sign-in in email).
 *
 * @var array $vars
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="bcb-wrap bcb-flow" data-flow>
	<div class="bcb-flow-shell">
		<div class="bcb-flow-header">
			<?php if ( ! empty( $vars['brand_logo'] ) ) : ?>
				<img src="<?php echo esc_url( $vars['brand_logo'] ); ?>" alt="<?php echo esc_attr( $vars['brand_name'] ); ?>" class="bcb-brand-logo">
			<?php else : ?>
				<h2 class="bcb-brand-title"><?php echo esc_html( $vars['brand_name'] ); ?></h2>
			<?php endif; ?>
		</div>

		<div class="bcb-flow-step is-active" data-step="1">
			<h3><?php esc_html_e( 'Sign in to your account', 'bye-chargeback-dashboard' ); ?></h3>
			<p><?php esc_html_e( 'Use the email and password we sent you to open your dashboard.', 'bye-chargeback-dashboard' ); ?></p>
			<form class="bcb-form" data-action="login">
				<label for="bcb-signin-email"><?php esc_html_e( 'Email', 'bye-chargeback-dashboard' ); ?></label>
				<input type="email" id="bcb-signin-email" name="email" required autocomplete="email">
				<label for="bcb-signin-password"><?php esc_html_e( 'Password', 'bye-chargeback-dashboard' ); ?></label>
				<input type="password" id="bcb-signin-password" name="password" required autocomplete="current-password">
				<button type="submit" class="bcb-btn bcb-btn-primary bcb-btn-block"><?php esc_html_e( 'Sign in', 'bye-chargeback-dashboard' ); ?></button>
			</form>
			<p class="bcb-flow-footnote">
				<?php esc_html_e( 'New here?', 'bye-chargeback-dashboard' ); ?>
				<a href="<?php echo esc_url( $vars['get_started_url'] ); ?>"><?php esc_html_e( 'Create an account', 'bye-chargeback-dashboard' ); ?></a>
			</p>
			<div class="bcb-form-message" data-message hidden></div>
		</div>
	</div>
</div>
