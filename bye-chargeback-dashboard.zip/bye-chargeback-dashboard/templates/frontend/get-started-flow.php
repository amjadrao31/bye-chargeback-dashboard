<?php
/**
 * Get started multi-step flow (doc page 1).
 *
 * Step 1: First screen after homepage button click.
 * Step 2: Email entry.
 * Step 3: Check email / sign-in prompt.
 *
 * @var array $vars
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="bcb-wrap bcb-flow" data-flow>
	<div class="bcb-flow-shell">
		<div class="bcb-flow-header">
			<?php if ( ! empty( $vars['brand_logo'] ) ) : ?>
				<img src="<?php echo esc_url( $vars['brand_logo'] ); ?>" alt="<?php echo esc_attr( $vars['brand_name'] ); ?>" class="bcb-brand-logo">
			<?php else : ?>
				<h2 class="bcb-brand-title"><?php echo esc_html( $vars['brand_name'] ); ?></h2>
			<?php endif; ?>
		</div>

		<div class="bcb-flow-progress" aria-hidden="true">
			<span class="is-active" data-progress="1"></span>
			<span data-progress="2"></span>
			<span data-progress="3"></span>
		</div>

		<!-- Step 1: First screen (after homepage button) -->
		<div class="bcb-flow-step is-active" data-step="1">
			<h3><?php esc_html_e( 'Stop chargebacks before they hurt your revenue', 'bye-chargeback-dashboard' ); ?></h3>
			<p><?php esc_html_e( 'ByeChargeBack monitors disputes, protects your payments, and gives you credits to fight back.', 'bye-chargeback-dashboard' ); ?></p>
			<ul class="bcb-flow-features">
				<li><?php esc_html_e( 'Real-time chargeback monitoring', 'bye-chargeback-dashboard' ); ?></li>
				<li><?php esc_html_e( 'Credit-based dispute prevention', 'bye-chargeback-dashboard' ); ?></li>
				<li><?php esc_html_e( 'Dedicated support when you need help', 'bye-chargeback-dashboard' ); ?></li>
			</ul>
			<button type="button" class="bcb-btn bcb-btn-primary bcb-btn-block" data-goto-step="2"><?php esc_html_e( 'Continue', 'bye-chargeback-dashboard' ); ?></button>
			<p class="bcb-flow-footnote">
				<?php esc_html_e( 'Already registered?', 'bye-chargeback-dashboard' ); ?>
				<a href="<?php echo esc_url( $vars['sign_in_url'] ); ?>"><?php esc_html_e( 'Sign in', 'bye-chargeback-dashboard' ); ?></a>
			</p>
		</div>

		<!-- Step 2: Email -->
		<div class="bcb-flow-step" data-step="2">
			<h3><?php esc_html_e( 'Enter your email to get started', 'bye-chargeback-dashboard' ); ?></h3>
			<p><?php esc_html_e( 'We will send you a sign-in link and your account details.', 'bye-chargeback-dashboard' ); ?></p>
			<form class="bcb-form" data-action="register">
				<label for="bcb-flow-email"><?php esc_html_e( 'Email address', 'bye-chargeback-dashboard' ); ?></label>
				<input type="email" id="bcb-flow-email" name="email" required placeholder="you@company.com" autocomplete="email">
				<button type="submit" class="bcb-btn bcb-btn-primary bcb-btn-block"><?php esc_html_e( 'Continue', 'bye-chargeback-dashboard' ); ?></button>
			</form>
			<button type="button" class="bcb-link-btn" data-goto-step="1"><?php esc_html_e( 'Back', 'bye-chargeback-dashboard' ); ?></button>
			<div class="bcb-form-message" data-message hidden></div>
		</div>

		<!-- Step 3: Check email -->
		<div class="bcb-flow-step" data-step="3">
			<div class="bcb-flow-success-icon">✉</div>
			<h3><?php esc_html_e( 'Check your email', 'bye-chargeback-dashboard' ); ?></h3>
			<p><?php esc_html_e( 'We sent a sign-in button and your account details to your inbox. Open the email to access your dashboard.', 'bye-chargeback-dashboard' ); ?></p>
			<a href="<?php echo esc_url( $vars['sign_in_url'] ); ?>" class="bcb-btn bcb-btn-primary bcb-btn-block"><?php esc_html_e( 'Sign in', 'bye-chargeback-dashboard' ); ?></a>
			<p class="bcb-flow-footnote">
				<?php esc_html_e( 'Didn\'t receive it?', 'bye-chargeback-dashboard' ); ?>
				<button type="button" class="bcb-link-btn" data-goto-step="2"><?php esc_html_e( 'Try another email', 'bye-chargeback-dashboard' ); ?></button>
			</p>
		</div>
	</div>
</div>
