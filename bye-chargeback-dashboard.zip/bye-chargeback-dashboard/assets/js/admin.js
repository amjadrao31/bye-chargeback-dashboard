(function ($) {
  'use strict';

  $('.bcb-upload-logo').on('click', function (e) {
    e.preventDefault();

    var frame = wp.media({
      title: 'Select Brand Logo',
      button: { text: 'Use this logo' },
      multiple: false
    });

    frame.on('select', function () {
      var attachment = frame.state().get('selection').first().toJSON();
      $('.bcb-logo-url').val(attachment.url);

      var preview = $('.bcb-logo-preview');
      if (preview.length) {
        preview.attr('src', attachment.url);
      } else {
        $('.bcb-logo-url').after('<p><img src="' + attachment.url + '" alt="" class="bcb-logo-preview"></p>');
      }
    });

    frame.open();
  });
})(jQuery);
