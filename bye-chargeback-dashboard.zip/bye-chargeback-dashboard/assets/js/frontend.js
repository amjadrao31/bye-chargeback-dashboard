(function () {
  'use strict';

  if (typeof bcbData === 'undefined') {
    return;
  }

  function post(action, data) {
    var body = new FormData();
    body.append('action', action);
    body.append('nonce', bcbData.nonce);
    Object.keys(data || {}).forEach(function (key) {
      body.append(key, data[key]);
    });
    return fetch(bcbData.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body }).then(function (res) {
      return res.json();
    });
  }

  function showMessage(el, text, type) {
    if (!el) return;
    el.hidden = false;
    el.textContent = text;
    el.className = 'bcb-form-message is-' + type;
  }

  function goToStep(flow, step) {
    flow.querySelectorAll('.bcb-flow-step').forEach(function (node) {
      node.classList.toggle('is-active', node.getAttribute('data-step') === String(step));
    });
    flow.querySelectorAll('[data-progress]').forEach(function (dot) {
      dot.classList.toggle('is-active', Number(dot.getAttribute('data-progress')) <= Number(step));
    });
  }

  document.querySelectorAll('[data-flow]').forEach(function (flow) {
    flow.addEventListener('click', function (e) {
      var goto = e.target.closest('[data-goto-step]');
      if (!goto) return;
      e.preventDefault();
      goToStep(flow, goto.getAttribute('data-goto-step'));
    });

    flow.querySelectorAll('.bcb-form').forEach(function (form) {
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var action = form.getAttribute('data-action');
        var messageEl = form.parentElement.querySelector('[data-message]');
        var submitBtn = form.querySelector('[type="submit"]');
        var payload = { email: form.querySelector('[name="email"]').value };

        if (action === 'login') {
          payload.password = form.querySelector('[name="password"]').value;
        }

        if (submitBtn) submitBtn.disabled = true;

        post(action === 'login' ? 'bcb_login' : 'bcb_register_email', payload)
          .then(function (response) {
            if (!response.success) {
              showMessage(messageEl, response.data && response.data.message ? response.data.message : 'Request failed.', 'error');
              return;
            }
            if (action === 'register') {
              goToStep(flow, '3');
              return;
            }
            window.location.href = response.data.redirect_url || bcbData.dashboardUrl;
          })
          .catch(function () {
            showMessage(messageEl, 'Something went wrong. Please try again.', 'error');
          })
          .finally(function () {
            if (submitBtn) submitBtn.disabled = false;
          });
      });
    });
  });

  var dashboard = document.querySelector('[data-dashboard]');
  if (!dashboard) return;

  var dealActive = false;

  function closeAllModals() {
    dashboard.querySelectorAll('[data-modal]').forEach(function (modal) {
      modal.hidden = true;
    });
  }

  function openModal(name) {
    closeAllModals();
    var modal = dashboard.querySelector('[data-modal="' + name + '"]');
    if (modal) modal.hidden = false;
  }

  function setDealMode(enabled) {
    dealActive = enabled;
    dashboard.querySelectorAll('[data-pricing-table]').forEach(function (table) {
      table.querySelectorAll('.bcb-price-standard').forEach(function (el) {
        el.hidden = enabled;
      });
      table.querySelectorAll('.bcb-price-deal').forEach(function (el) {
        el.hidden = !enabled;
      });
      table.querySelectorAll('.bcb-buy-plan').forEach(function (link) {
        link.href = enabled ? link.getAttribute('data-link-deal') : link.getAttribute('data-link-standard');
      });
    });
    dashboard.querySelectorAll('[data-deal-toggle]').forEach(function (btn) {
      btn.classList.toggle('is-active', enabled);
    });
  }

  dashboard.addEventListener('click', function (e) {
    var openBtn = e.target.closest('[data-open]');
    if (openBtn) {
      openModal(openBtn.getAttribute('data-open'));
      if (openBtn.hasAttribute('data-close-popover')) {
        var tips = dashboard.querySelector('[data-modal="dispute-tips"]');
        if (tips) tips.hidden = true;
      }
    }

    var dealToggle = e.target.closest('[data-deal-toggle]');
    if (dealToggle) {
      setDealMode(!dealActive);
    }

    var closeEl = e.target.closest('[data-close]');
    if (closeEl) {
      closeAllModals();
    }

    var toggleAccount = e.target.closest('[data-toggle="account"]');
    if (toggleAccount) {
      var dropdown = dashboard.querySelector('.bcb-account-dropdown');
      if (dropdown) dropdown.hidden = !dropdown.hidden;
    }

    var viewBtn = e.target.closest('[data-view]');
    if (viewBtn) {
      dashboard.querySelectorAll('[data-panel]').forEach(function (panel) {
        var match = panel.getAttribute('data-panel') === viewBtn.getAttribute('data-view');
        panel.hidden = !match;
        panel.classList.toggle('is-active', match);
      });
      closeAllModals();
      var dd = dashboard.querySelector('.bcb-account-dropdown');
      if (dd) dd.hidden = true;
    }

    var protectBtn = e.target.closest('[data-protect-account]');
    if (protectBtn) {
      var errorWrap = dashboard.querySelector('[data-protect-errors]');
      post('bcb_protect_account', {}).then(function (response) {
        if (!errorWrap) return;
        var messages = (response.data && response.data.messages) || bcbData.protectErrors || [];
        errorWrap.innerHTML = messages.map(function (msg) {
          return '<div class="bcb-alert bcb-alert-error">' + msg + '</div>';
        }).join('');
        errorWrap.hidden = false;
      });
    }

    var tooltipTrigger = e.target.closest('.bcb-tooltip-trigger');
    if (tooltipTrigger) {
      var popup = dashboard.querySelector('[data-tooltip-popup]');
      var data = JSON.parse(tooltipTrigger.getAttribute('data-tooltip') || '{}');
      if (popup) {
        popup.querySelector('[data-tooltip-title]').textContent = data.label || '';
        popup.querySelector('[data-tooltip-text]').textContent = data.text || '';
        popup.hidden = false;
        var rect = tooltipTrigger.getBoundingClientRect();
        popup.style.top = (rect.bottom + window.scrollY + 8) + 'px';
        popup.style.left = Math.max(16, rect.left) + 'px';
      }
    }
  });

  document.addEventListener('click', function (e) {
    if (!dashboard.contains(e.target)) return;

    if (!e.target.closest('.bcb-tooltip-trigger') && !e.target.closest('[data-tooltip-popup]')) {
      var popup = dashboard.querySelector('[data-tooltip-popup]');
      if (popup) popup.hidden = true;
    }

    if (!e.target.closest('[data-account-menu]')) {
      var dropdown = dashboard.querySelector('.bcb-account-dropdown');
      if (dropdown) dropdown.hidden = true;
    }

    if (!e.target.closest('[data-open="dispute-tips"]') && !e.target.closest('[data-modal="dispute-tips"]')) {
      var tips = dashboard.querySelector('[data-modal="dispute-tips"]');
      if (tips && !tips.hidden && !e.target.closest('[data-open="credits"]')) {
        tips.hidden = true;
      }
    }

    if (!e.target.closest('[data-open="alerts"]') && !e.target.closest('[data-modal="alerts"]')) {
      var alerts = dashboard.querySelector('[data-modal="alerts"]');
      if (alerts && !alerts.hidden) alerts.hidden = true;
    }
  });
})();
