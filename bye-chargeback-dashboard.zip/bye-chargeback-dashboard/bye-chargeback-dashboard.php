<?php
/**
 * Plugin Name: ByeChargeBack Custom Dashboard
 * Plugin URI:  https://byechargeback.com/
 * Description: Custom user dashboard with signup flow, credits, billing, alerts, and admin-configurable pricing links for ByeChargeBack.
 * Version:     1.2.2
 * Author:      ByeChargeBack
 * Author URI:  https://byechargeback.com/
 * Text Domain: bye-chargeback-dashboard
 * Requires at least: 6.0
 * Requires PHP: 7.4
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;

define( 'BCB_VERSION', '1.2.2' );
define( 'BCB_PLUGIN_FILE', __FILE__ );
define( 'BCB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'BCB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once BCB_PLUGIN_DIR . 'includes/class-bcb-settings.php';
require_once BCB_PLUGIN_DIR . 'includes/class-bcb-mail.php';
require_once BCB_PLUGIN_DIR . 'includes/class-bcb-admin.php';
require_once BCB_PLUGIN_DIR . 'includes/class-bcb-frontend.php';
require_once BCB_PLUGIN_DIR . 'includes/class-bcb-ajax.php';

/**
 * Main plugin bootstrap.
 */
final class BCB_Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var BCB_Plugin|null
	 */
	private static $instance = null;

	/**
	 * Get plugin instance.
	 *
	 * @return BCB_Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		register_activation_hook( BCB_PLUGIN_FILE, array( $this, 'activate' ) );

		add_action( 'init', array( $this, 'init' ) );
		add_action( 'wp_enqueue_scripts', array( 'BCB_Frontend', 'enqueue_assets' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

		BCB_Admin::init();
		BCB_Mail::init();
		BCB_Frontend::init();
		BCB_Ajax::init();
	}

	/**
	 * Plugin activation defaults and pages.
	 */
	public function activate() {
		if ( ! get_option( BCB_Settings::OPTION_KEY ) ) {
			update_option( BCB_Settings::OPTION_KEY, BCB_Settings::defaults() );
		}

		BCB_Frontend::maybe_create_pages();
	}

	/**
	 * Register text domain.
	 */
	public function init() {
		load_plugin_textdomain( 'bye-chargeback-dashboard', false, dirname( plugin_basename( BCB_PLUGIN_FILE ) ) . '/languages' );
	}

	/**
	 * Enqueue admin assets on plugin settings screen.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( 'toplevel_page_bcb-dashboard-settings' !== $hook ) {
			return;
		}

		wp_enqueue_media();

		wp_enqueue_style(
			'bcb-gabarito',
			'https://fonts.googleapis.com/css2?family=Gabarito:wght@400;500;600;700;800&display=swap',
			array(),
			null
		);

		wp_enqueue_style(
			'bcb-admin',
			BCB_PLUGIN_URL . 'assets/css/admin.css',
			array( 'bcb-gabarito' ),
			BCB_VERSION
		);

		wp_enqueue_script(
			'bcb-admin',
			BCB_PLUGIN_URL . 'assets/js/admin.js',
			array( 'jquery' ),
			BCB_VERSION,
			true
		);
	}
}

BCB_Plugin::instance();
