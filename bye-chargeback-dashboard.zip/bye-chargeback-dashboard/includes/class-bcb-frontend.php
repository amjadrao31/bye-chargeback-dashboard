<?php
/**
 * Frontend shortcodes and templates.
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;

/**
 * Public-facing dashboard and signup flow.
 */
class BCB_Frontend {

	const SHORTCODES = array(
		'bcb_home_button',
		'bcb_get_started',
		'bcb_dashboard',
		'bcb_sign_in',
	);

	/**
	 * Whether frontend assets were enqueued.
	 *
	 * @var bool
	 */
	private static $assets_enqueued = false;

	/**
	 * Initialize hooks.
	 */
	public static function init() {
		add_shortcode( 'bcb_home_button', array( __CLASS__, 'render_home_button' ) );
		add_shortcode( 'bcb_get_started', array( __CLASS__, 'render_get_started' ) );
		add_shortcode( 'bcb_dashboard', array( __CLASS__, 'render_dashboard' ) );
		add_shortcode( 'bcb_sign_in', array( __CLASS__, 'render_sign_in' ) );

		add_filter( 'show_admin_bar', array( __CLASS__, 'hide_admin_bar' ) );
		add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
		add_action( 'wp_head', array( __CLASS__, 'app_page_head_styles' ), 99 );
	}

	/**
	 * Hide the WordPress admin bar on plugin frontend pages.
	 *
	 * @param bool $show Whether to show the admin bar.
	 * @return bool
	 */
	public static function hide_admin_bar( $show ) {
		if ( self::current_page_has_shortcode() ) {
			return false;
		}

		return $show;
	}

	/**
	 * Add body classes for full-screen app pages.
	 *
	 * @param string[] $classes Body classes.
	 * @return string[]
	 */
	public static function body_class( $classes ) {
		if ( ! self::current_page_has_shortcode() ) {
			return $classes;
		}

		$classes[] = 'bcb-app-page';

		if ( self::is_dashboard_page() ) {
			$classes[] = 'bcb-dashboard-page';
		}

		return $classes;
	}

	/**
	 * Reset admin-bar spacing and hide bar if theme still renders it.
	 */
	public static function app_page_head_styles() {
		if ( ! self::current_page_has_shortcode() ) {
			return;
		}

		echo '<style id="bcb-app-page-styles">html{margin-top:0!important}body.admin-bar{margin-top:0!important;padding-top:0!important}#wpadminbar{display:none!important;visibility:hidden!important}</style>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Whether the current page is the configured dashboard page.
	 *
	 * @return bool
	 */
	public static function is_dashboard_page() {
		if ( ! is_singular() ) {
			return false;
		}

		$post = get_post();

		if ( ! $post instanceof WP_Post ) {
			return false;
		}

		$dashboard_id = (int) BCB_Settings::get( 'dashboard_page_id', 0 );

		if ( $dashboard_id > 0 && (int) $post->ID === $dashboard_id ) {
			return true;
		}

		return has_shortcode( $post->post_content, 'bcb_dashboard' );
	}

	/**
	 * Detect shortcodes in content and enqueue assets early.
	 */
	public static function enqueue_assets() {
		if ( self::$assets_enqueued || is_admin() ) {
			return;
		}

		if ( self::current_page_has_shortcode() ) {
			self::register_assets();
		}
	}

	/**
	 * Force asset registration (called from shortcodes as fallback).
	 */
	public static function register_assets() {
		if ( self::$assets_enqueued ) {
			return;
		}

		self::$assets_enqueued = true;

		wp_enqueue_style(
			'bcb-gabarito',
			'https://fonts.googleapis.com/css2?family=Gabarito:wght@400;500;600;700;800&display=swap',
			array(),
			null
		);

		wp_enqueue_style(
			'bcb-frontend',
			BCB_PLUGIN_URL . 'assets/css/frontend.css',
			array( 'bcb-gabarito' ),
			BCB_VERSION
		);

		wp_enqueue_script(
			'bcb-frontend',
			BCB_PLUGIN_URL . 'assets/js/frontend.js',
			array(),
			BCB_VERSION,
			true
		);

		$settings = BCB_Settings::all();

		wp_localize_script(
			'bcb-frontend',
			'bcbData',
			array(
				'ajaxUrl'         => admin_url( 'admin-ajax.php' ),
				'nonce'           => wp_create_nonce( 'bcb_frontend' ),
				'logoutUrl'       => wp_logout_url( $settings['logout_redirect_url'] ),
				'supportEmail'    => $settings['brand_email'],
				'discountPercent' => (float) $settings['discount_percent'],
				'pricing'         => BCB_Settings::get_pricing_with_discount(),
				'links'           => BCB_Settings::get_links(),
				'dashboardUrl'    => self::get_dashboard_page_url(),
				'signInUrl'       => self::get_sign_in_page_url(),
				'protectErrors'   => array_values( (array) $settings['protect_account_errors'] ),
			)
		);
	}

	/**
	 * Check if the current singular post contains plugin shortcodes.
	 *
	 * @return bool
	 */
	private static function current_page_has_shortcode() {
		if ( ! is_singular() ) {
			return false;
		}

		$post = get_post();

		if ( ! $post instanceof WP_Post ) {
			return false;
		}

		foreach ( self::SHORTCODES as $shortcode ) {
			if ( has_shortcode( $post->post_content, $shortcode ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get configured dashboard page URL.
	 *
	 * @return string
	 */
	public static function get_dashboard_page_url() {
		$page_id = (int) BCB_Settings::get( 'dashboard_page_id', 0 );

		if ( $page_id > 0 && get_post_status( $page_id ) ) {
			return get_permalink( $page_id );
		}

		return home_url( '/dashboard/' );
	}

	/**
	 * Get configured get-started page URL.
	 *
	 * @return string
	 */
	public static function get_started_page_url() {
		$page_id = (int) BCB_Settings::get( 'get_started_page_id', 0 );

		if ( $page_id > 0 && get_post_status( $page_id ) ) {
			return get_permalink( $page_id );
		}

		return home_url( '/get-started/' );
	}

	/**
	 * Get configured sign-in page URL.
	 *
	 * @return string
	 */
	public static function get_sign_in_page_url() {
		$page_id = (int) BCB_Settings::get( 'sign_in_page_id', 0 );

		if ( $page_id > 0 && get_post_status( $page_id ) ) {
			return get_permalink( $page_id );
		}

		return self::get_started_page_url();
	}

	/**
	 * Create default pages on activation if missing.
	 */
	public static function maybe_create_pages() {
		$settings = BCB_Settings::all();
		$changed  = false;

		if ( empty( $settings['get_started_page_id'] ) || ! get_post_status( $settings['get_started_page_id'] ) ) {
			$settings['get_started_page_id'] = self::create_page(
				__( 'Get Started', 'bye-chargeback-dashboard' ),
				'get-started',
				'[bcb_get_started]'
			);
			$changed = true;
		}

		if ( empty( $settings['sign_in_page_id'] ) || ! get_post_status( $settings['sign_in_page_id'] ) ) {
			$settings['sign_in_page_id'] = self::create_page(
				__( 'Sign In', 'bye-chargeback-dashboard' ),
				'sign-in',
				'[bcb_sign_in]'
			);
			$changed = true;
		}

		if ( empty( $settings['dashboard_page_id'] ) || ! get_post_status( $settings['dashboard_page_id'] ) ) {
			$settings['dashboard_page_id'] = self::create_page(
				__( 'Dashboard', 'bye-chargeback-dashboard' ),
				'dashboard',
				'[bcb_dashboard]'
			);
			$changed = true;
		}

		if ( $changed ) {
			BCB_Settings::save( $settings );
		}
	}

	/**
	 * Insert a published page.
	 *
	 * @param string $title    Page title.
	 * @param string $slug     Page slug.
	 * @param string $content  Page content.
	 * @return int
	 */
	private static function create_page( $title, $slug, $content ) {
		$existing = get_page_by_path( $slug );

		if ( $existing instanceof WP_Post ) {
			return (int) $existing->ID;
		}

		return (int) wp_insert_post(
			array(
				'post_title'   => $title,
				'post_name'    => $slug,
				'post_content' => $content,
				'post_status'  => 'publish',
				'post_type'    => 'page',
			)
		);
	}

	/**
	 * Shared template variables.
	 *
	 * @return array
	 */
	public static function template_vars() {
		$settings = BCB_Settings::all();

		return array(
			'brand_name'      => $settings['brand_name'],
			'brand_email'     => $settings['brand_email'],
			'brand_logo'      => $settings['brand_logo_url'],
			'highlight_color' => $settings['rule_highlight_color'],
			'highlight_bg'    => $settings['rule_highlight_bg'],
			'tooltips'        => $settings['tooltip_rules'],
			'dispute_tips'    => $settings['dispute_tips'],
			'dispute_tips_title'  => $settings['dispute_tips_title'],
			'dispute_tips_unlock' => $settings['dispute_tips_unlock'],
			'protect_errors'  => $settings['protect_account_errors'],
			'billing_error'   => $settings['billing_error_message'],
			'pricing'         => BCB_Settings::get_pricing_with_discount(),
			'links'           => BCB_Settings::get_links(),
			'discount'        => (float) $settings['discount_percent'],
			'discount_code'   => $settings['discount_code'],
			'credits_headline'=> $settings['credits_headline'],
			'credits_benefits'=> $settings['credits_benefits'],
			'promo_banner'    => BCB_Settings::get_promo_banner_text(),
			'faq_items'       => $settings['faq_items'],
			'testimonial'     => array(
				'quote'  => $settings['testimonial_quote'],
				'name'   => $settings['testimonial_name'],
				'handle' => $settings['testimonial_handle'],
			),
			'logout_url'               => wp_logout_url( $settings['logout_redirect_url'] ),
			'sign_in_url'              => self::get_sign_in_page_url(),
			'dashboard_url'            => self::get_dashboard_page_url(),
			'get_started_url'          => self::get_started_page_url(),
			'support_mailto'           => 'mailto:' . antispambot( $settings['brand_email'] ) . '?subject=' . rawurlencode( $settings['support_subject'] ),
			'dashboard_account_title'  => $settings['dashboard_account_title'],
			'protection_rules'         => $settings['protection_rules'],
			'credits_required_message' => $settings['credits_required_message'],
		);
	}

	/**
	 * Homepage CTA button (doc: first action on homepage).
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render_home_button( $atts ) {
		self::register_assets();

		$atts = shortcode_atts(
			array(
				'text' => __( 'Protect My Business', 'bye-chargeback-dashboard' ),
				'url'  => '',
			),
			$atts,
			'bcb_home_button'
		);

		$url = ! empty( $atts['url'] ) ? $atts['url'] : self::get_started_page_url();

		if ( is_user_logged_in() ) {
			$url = self::get_dashboard_page_url();
			$atts['text'] = __( 'Open Dashboard', 'bye-chargeback-dashboard' );
		}

		return sprintf(
			'<div class="bcb-wrap bcb-home-cta"><a class="bcb-btn bcb-btn-primary bcb-btn-lg" href="%s">%s</a></div>',
			esc_url( $url ),
			esc_html( $atts['text'] )
		);
	}

	/**
	 * Multi-step onboarding (doc pages 1–2).
	 *
	 * @return string
	 */
	public static function render_get_started() {
		self::register_assets();

		if ( is_user_logged_in() ) {
			return sprintf(
				'<div class="bcb-wrap bcb-flow"><div class="bcb-flow-shell"><p>%s</p><a class="bcb-btn bcb-btn-primary" href="%s">%s</a></div></div>',
				esc_html__( 'You are already signed in.', 'bye-chargeback-dashboard' ),
				esc_url( self::get_dashboard_page_url() ),
				esc_html__( 'Open Dashboard', 'bye-chargeback-dashboard' )
			);
		}

		$vars = self::template_vars();
		ob_start();
		include BCB_PLUGIN_DIR . 'templates/frontend/get-started-flow.php';

		return ob_get_clean();
	}

	/**
	 * Sign-in screen (doc: screen after clicking sign-in in email).
	 *
	 * @return string
	 */
	public static function render_sign_in() {
		self::register_assets();

		if ( is_user_logged_in() ) {
			return sprintf(
				'<div class="bcb-wrap bcb-flow"><div class="bcb-flow-shell"><p>%s</p><a class="bcb-btn bcb-btn-primary" href="%s">%s</a></div></div>',
				esc_html__( 'You are already signed in.', 'bye-chargeback-dashboard' ),
				esc_url( self::get_dashboard_page_url() ),
				esc_html__( 'Open Dashboard', 'bye-chargeback-dashboard' )
			);
		}

		$vars = self::template_vars();
		ob_start();
		include BCB_PLUGIN_DIR . 'templates/frontend/sign-in.php';

		return ob_get_clean();
	}

	/**
	 * Render main dashboard.
	 *
	 * @return string
	 */
	public static function render_dashboard() {
		self::register_assets();

		if ( ! is_user_logged_in() ) {
			return sprintf(
				'<div class="bcb-wrap bcb-notice bcb-notice-warning"><p>%s <a class="bcb-btn bcb-btn-primary" href="%s">%s</a></p></div>',
				esc_html__( 'Please sign in to access your dashboard.', 'bye-chargeback-dashboard' ),
				esc_url( self::get_sign_in_page_url() ),
				esc_html__( 'Sign in', 'bye-chargeback-dashboard' )
			);
		}

		$vars            = self::template_vars();
		$vars['user']    = wp_get_current_user();
		$vars['credits'] = (int) get_user_meta( $vars['user']->ID, 'bcb_credits', true );

		$user    = $vars['user'];
		$credits = $vars['credits'];

		ob_start();
		include BCB_PLUGIN_DIR . 'templates/frontend/dashboard.php';

		return ob_get_clean();
	}
}
