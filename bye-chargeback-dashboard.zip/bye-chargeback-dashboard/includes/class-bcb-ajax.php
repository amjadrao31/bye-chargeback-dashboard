<?php
/**
 * AJAX handlers for signup and dashboard actions.
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;

/**
 * AJAX endpoints.
 */
class BCB_Ajax {

	/**
	 * Initialize hooks.
	 */
	public static function init() {
		$actions = array(
			'bcb_register_email',
			'bcb_login',
			'bcb_protect_account',
		);

		foreach ( $actions as $action ) {
			$handler = str_replace( 'bcb_', 'handle_', $action );
			add_action( "wp_ajax_{$action}", array( __CLASS__, $handler ) );
			add_action( "wp_ajax_nopriv_{$action}", array( __CLASS__, $handler ) );
		}
	}

	/**
	 * Verify nonce for frontend requests.
	 */
	private static function verify_nonce() {
		check_ajax_referer( 'bcb_frontend', 'nonce' );
	}

	/**
	 * Register user by email — sends sign-in email, does NOT auto-login.
	 */
	public static function handle_register_email() {
		self::verify_nonce();

		$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );

		if ( ! is_email( $email ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Please enter a valid email address.', 'bye-chargeback-dashboard' ) ),
				400
			);
		}

		$user     = get_user_by( 'email', $email );
		$is_new   = false;
		$password = wp_generate_password( 12, false, false );

		if ( ! $user ) {
			$username = sanitize_user( current( explode( '@', $email ) ), true );
			$base     = $username;
			$counter  = 1;

			while ( username_exists( $username ) ) {
				$username = $base . $counter;
				++$counter;
			}

			$user_id = wp_create_user( $username, $password, $email );

			if ( is_wp_error( $user_id ) ) {
				wp_send_json_error(
					array( 'message' => $user_id->get_error_message() ),
					400
				);
			}

			update_user_meta( $user_id, 'bcb_credits', 0 );
			$user   = get_user_by( 'id', $user_id );
			$is_new = true;
		} else {
			wp_set_password( $password, $user->ID );
		}

		$sent = BCB_Mail::send_sign_in_email( $user, $password, $is_new );

		if ( ! $sent ) {
			wp_send_json_error(
				array(
					'message'   => BCB_Mail::get_failure_hint(),
					'signInUrl' => BCB_Frontend::get_sign_in_page_url(),
				),
				500
			);
		}

		wp_send_json_success(
			array(
				'message'   => __( 'Check your inbox. We sent your sign-in button, email, and password.', 'bye-chargeback-dashboard' ),
				'signInUrl' => BCB_Frontend::get_sign_in_page_url(),
			)
		);
	}

	/**
	 * Login existing user by email + password.
	 */
	public static function handle_login() {
		self::verify_nonce();

		$email    = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
		$password = wp_unslash( $_POST['password'] ?? '' );

		if ( ! is_email( $email ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Please enter a valid email address.', 'bye-chargeback-dashboard' ) ),
				400
			);
		}

		if ( empty( $password ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Please enter your password.', 'bye-chargeback-dashboard' ) ),
				400
			);
		}

		$account = get_user_by( 'email', $email );

		if ( ! $account ) {
			wp_send_json_error(
				array( 'message' => __( 'No account found for that email. Please register first.', 'bye-chargeback-dashboard' ) ),
				404
			);
		}

		$user = wp_authenticate( $account->user_login, $password );

		if ( is_wp_error( $user ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid email or password.', 'bye-chargeback-dashboard' ) ),
				401
			);
		}

		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true );

		wp_send_json_success(
			array(
				'redirect_url' => BCB_Frontend::get_dashboard_page_url(),
			)
		);
	}

	/**
	 * Return all protect-account error messages from settings.
	 */
	public static function handle_protect_account() {
		self::verify_nonce();

		if ( ! is_user_logged_in() ) {
			wp_send_json_error(
				array( 'message' => __( 'You must be signed in.', 'bye-chargeback-dashboard' ) ),
				401
			);
		}

		$errors = array_values(
			array_filter(
				(array) BCB_Settings::get( 'protect_account_errors', array() )
			)
		);

		if ( empty( $errors ) ) {
			$errors = array( __( 'Unable to activate protection.', 'bye-chargeback-dashboard' ) );
		}

		wp_send_json_error(
			array( 'messages' => $errors ),
			422
		);
	}
}
