<?php
/**
 * Plugin settings helper.
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;

/**
 * Settings storage and defaults.
 */
class BCB_Settings {

	const OPTION_KEY = 'bcb_settings';

	/**
	 * Default settings from product spec + document screenshots.
	 *
	 * @return array
	 */
	public static function defaults() {
		return array(
			'brand_name'             => 'ByeChargeBack',
			'brand_email'            => 'contact@ByeChargeBack.com',
			'brand_logo_url'         => '',
			'logout_redirect_url'      => 'https://byechargeback.com/',
			'discount_percent'       => 30,
			'discount_code'          => 'JUNE',
			'credits_headline'       => 'Prevent disputes before they arise',
			'credits_benefits'       => array(
				'Save €30 per dispute',
				'Up to 80% less disputes',
				'1-minute no-code setup',
			),
			'promo_banner_text'      => 'Use the code {code} for {discount}% off this month only.',
			'rule_highlight_color'   => '#134074',
			'rule_highlight_bg'      => '#EEF4ED',
			'dashboard_account_title' => 'New Stripe account',
			'credits_required_message' => 'You need to buy credits to protect a Stripe account.',
			'protection_rules'       => array(
				array(
					'condition' => 'payment with suspicious email',
					'action'    => 'send email alert',
				),
			),
			'support_subject'          => 'Support Request - ByeChargeBack',
			'testimonial_quote'      => 'I like to ship startups fast. Implementing a full chargeback protection system would have wasted me days. I was able to add it with one click with ByeChargeBack.',
			'testimonial_name'       => 'Nico Jeannen',
			'testimonial_handle'     => '@nico_jeannen • 16.7k followers',
			'dispute_tips_title'     => 'Tips to prevent disputes',
			'dispute_tips_unlock'    => 'Upgrade your account to unlock.',
			'protect_account_errors' => array(
				'Unable to enable protection. Please verify your billing details.',
				'Your account requires additional verification before protection can be activated.',
				'Protection service is temporarily unavailable. Please try again later.',
			),
			'billing_error_message'  => 'We could not load your billing information. Please update your payment method or contact support.',
			'dispute_tips'           => array(
				'Respond to chargeback notifications within 24 hours.',
				'Keep delivery confirmations and customer communication logs ready.',
				'Use clear product descriptions and transparent refund policies.',
			),
			'tooltip_rules'          => array(
				array(
					'label' => 'chargeback protection',
					'text'  => 'Monitors transactions and helps prevent disputes before they become chargebacks.',
				),
				array(
					'label' => 'credit balance',
					'text'  => 'Credits are used when disputes are prevented or resolved on your behalf.',
				),
				array(
					'label' => 'protected transactions',
					'text'  => 'Each plan includes a monthly volume of transactions covered by protection.',
				),
			),
			'faq_items'              => array(
				array(
					'question' => 'How does it work?',
					'answer'   => 'Connect your store, add credits, and ByeChargeBack monitors transactions for dispute risk.',
				),
				array(
					'question' => 'Can I have multiple Stripe accounts?',
					'answer'   => 'Yes, you can protect multiple accounts from one dashboard.',
				),
				array(
					'question' => 'Do I need coding skills?',
					'answer'   => 'No. Setup takes about one minute with no code required.',
				),
			),
			'pricing'                => array(
				array( 'label' => 'Starter', 'transactions' => '5,000 Protected Transactions', 'price' => 80 ),
				array( 'label' => 'Growth', 'transactions' => '10,000 Protected Transactions', 'price' => 90 ),
				array( 'label' => 'Pro', 'transactions' => '30,000 Protected Transactions', 'price' => 100 ),
				array( 'label' => 'Enterprise', 'transactions' => '100,000 Protected Transactions', 'price' => 160 ),
			),
			'links'                  => array(
				'plan_1_standard' => '',
				'plan_1_deal'     => '',
				'plan_2_standard' => '',
				'plan_2_deal'     => '',
				'plan_3_standard' => '',
				'plan_3_deal'     => '',
				'plan_4_standard' => '',
				'plan_4_deal'     => '',
			),
			'dashboard_page_id'      => 0,
			'get_started_page_id'    => 0,
			'sign_in_page_id'        => 0,
		);
	}

	/**
	 * Get all settings merged with defaults.
	 *
	 * @return array
	 */
	public static function all() {
		$stored = get_option( self::OPTION_KEY, array() );

		return wp_parse_args( is_array( $stored ) ? $stored : array(), self::defaults() );
	}

	/**
	 * Get a single setting.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public static function get( $key, $default = null ) {
		$settings = self::all();

		return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
	}

	/**
	 * Save settings array.
	 *
	 * @param array $settings Settings to save.
	 */
	public static function save( array $settings ) {
		update_option( self::OPTION_KEY, $settings );
	}

	/**
	 * Get pricing tiers with discounted prices applied.
	 *
	 * @return array
	 */
	public static function get_pricing_with_discount() {
		$settings = self::all();
		$discount = max( 0, min( 100, (float) $settings['discount_percent'] ) );
		$pricing  = array();

		foreach ( $settings['pricing'] as $index => $tier ) {
			$price      = (float) $tier['price'];
			$discounted = round( $price * ( 1 - ( $discount / 100 ) ), 2 );

			$pricing[] = array(
				'index'        => $index + 1,
				'label'        => $tier['label'],
				'transactions' => $tier['transactions'] ?? '',
				'price'        => $price,
				'discounted'   => $discounted,
				'currency'     => '€',
			);
		}

		return $pricing;
	}

	/**
	 * Get checkout links keyed by plan index.
	 *
	 * @return array
	 */
	public static function get_links() {
		$settings = self::all();
		$links    = array();

		for ( $i = 1; $i <= 4; $i++ ) {
			$links[ $i ] = array(
				'standard' => esc_url( $settings['links'][ "plan_{$i}_standard" ] ?? '' ),
				'deal'     => esc_url( $settings['links'][ "plan_{$i}_deal" ] ?? '' ),
			);
		}

		return $links;
	}

	/**
	 * Build promo banner text with placeholders replaced.
	 *
	 * @return string
	 */
	public static function get_promo_banner_text() {
		$settings = self::all();

		return str_replace(
			array( '{code}', '{discount}' ),
			array( $settings['discount_code'], $settings['discount_percent'] ),
			$settings['promo_banner_text']
		);
	}

	/**
	 * Sanitize settings from admin form.
	 *
	 * @param array $input Raw input.
	 * @return array
	 */
	public static function sanitize( array $input ) {
		$defaults = self::defaults();
		$output   = self::all();

		$output['brand_name']          = sanitize_text_field( $input['brand_name'] ?? $defaults['brand_name'] );
		$output['brand_email']         = sanitize_email( $input['brand_email'] ?? $defaults['brand_email'] );

		$text_fields = array(
			'discount_code', 'credits_headline', 'promo_banner_text', 'support_subject',
			'testimonial_name', 'testimonial_handle', 'dispute_tips_title', 'dispute_tips_unlock',
		);

		foreach ( $text_fields as $field ) {
			if ( isset( $input[ $field ] ) ) {
				$output[ $field ] = sanitize_text_field( $input[ $field ] );
			}
		}

		$output['brand_logo_url']      = esc_url_raw( $input['brand_logo_url'] ?? '' );
		$output['logout_redirect_url'] = esc_url_raw( $input['logout_redirect_url'] ?? $defaults['logout_redirect_url'] );
		$output['discount_percent']    = max( 0, min( 100, (float) ( $input['discount_percent'] ?? 10 ) ) );
		$output['rule_highlight_color'] = sanitize_hex_color( $input['rule_highlight_color'] ?? $defaults['rule_highlight_color'] ) ?: $defaults['rule_highlight_color'];
		$output['rule_highlight_bg']    = sanitize_hex_color( $input['rule_highlight_bg'] ?? $defaults['rule_highlight_bg'] ) ?: $defaults['rule_highlight_bg'];
		$output['billing_error_message'] = sanitize_textarea_field( $input['billing_error_message'] ?? $defaults['billing_error_message'] );
		$output['testimonial_quote']    = sanitize_textarea_field( $input['testimonial_quote'] ?? $defaults['testimonial_quote'] );
		$output['dashboard_page_id']    = absint( $input['dashboard_page_id'] ?? 0 );
		$output['get_started_page_id']  = absint( $input['get_started_page_id'] ?? 0 );
		$output['sign_in_page_id']      = absint( $input['sign_in_page_id'] ?? 0 );

		if ( ! empty( $input['credits_benefits'] ) && is_array( $input['credits_benefits'] ) ) {
			$output['credits_benefits'] = array_values( array_filter( array_map( 'sanitize_text_field', $input['credits_benefits'] ) ) );
		}

		if ( ! empty( $input['protect_account_errors'] ) && is_array( $input['protect_account_errors'] ) ) {
			$output['protect_account_errors'] = array_values( array_filter( array_map( 'sanitize_text_field', $input['protect_account_errors'] ) ) );
		}

		if ( ! empty( $input['dispute_tips'] ) && is_array( $input['dispute_tips'] ) ) {
			$output['dispute_tips'] = array_values( array_filter( array_map( 'sanitize_textarea_field', $input['dispute_tips'] ) ) );
		}

		if ( ! empty( $input['pricing'] ) && is_array( $input['pricing'] ) ) {
			$output['pricing'] = array();
			foreach ( $input['pricing'] as $tier ) {
				if ( ! isset( $tier['price'] ) || '' === (string) $tier['price'] ) {
					continue;
				}
				$output['pricing'][] = array(
					'label'        => sanitize_text_field( $tier['label'] ?? '' ),
					'transactions' => sanitize_text_field( $tier['transactions'] ?? '' ),
					'price'        => max( 0, (float) ( $tier['price'] ?? 0 ) ),
				);
			}
		}

		if ( ! empty( $input['links'] ) && is_array( $input['links'] ) ) {
			foreach ( $input['links'] as $key => $url ) {
				$output['links'][ sanitize_key( $key ) ] = esc_url_raw( $url );
			}
		}

		if ( ! empty( $input['tooltip_rules'] ) && is_array( $input['tooltip_rules'] ) ) {
			$output['tooltip_rules'] = array();
			foreach ( $input['tooltip_rules'] as $rule ) {
				if ( empty( $rule['label'] ) ) {
					continue;
				}
				$output['tooltip_rules'][] = array(
					'label' => sanitize_text_field( $rule['label'] ),
					'text'  => sanitize_textarea_field( $rule['text'] ?? '' ),
				);
			}
		}

		if ( ! empty( $input['faq_items'] ) && is_array( $input['faq_items'] ) ) {
			$output['faq_items'] = array();
			foreach ( $input['faq_items'] as $item ) {
				if ( empty( $item['question'] ) ) {
					continue;
				}
				$output['faq_items'][] = array(
					'question' => sanitize_text_field( $item['question'] ),
					'answer'   => sanitize_textarea_field( $item['answer'] ?? '' ),
				);
			}
		}

		return $output;
	}
}
