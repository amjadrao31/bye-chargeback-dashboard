<?php
/**
 * Admin settings page.
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;

/**
 * WordPress admin integration.
 */
class BCB_Admin {

	/**
	 * Initialize hooks.
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_save' ) );
	}

	/**
	 * Register top-level menu.
	 */
	public static function register_menu() {
		add_menu_page(
			__( 'ByeChargeBack Dashboard', 'bye-chargeback-dashboard' ),
			__( 'BCB Dashboard', 'bye-chargeback-dashboard' ),
			'manage_options',
			'bcb-dashboard-settings',
			array( __CLASS__, 'render_settings_page' ),
			'dashicons-shield',
			58
		);
	}

	/**
	 * Handle settings form submission.
	 */
	public static function handle_save() {
		if ( ! isset( $_POST['bcb_save_settings'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		check_admin_referer( 'bcb_save_settings' );

		$input    = wp_unslash( $_POST['bcb'] ?? array() );
		$settings = BCB_Settings::sanitize( is_array( $input ) ? $input : array() );
		BCB_Settings::save( $settings );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'             => 'bcb-dashboard-settings',
					'bcb-settings-saved' => '1',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Render admin settings page.
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$settings = BCB_Settings::all();
		$pages    = get_pages( array( 'sort_column' => 'post_title' ) );
		$pricing  = BCB_Settings::get_pricing_with_discount();

		include BCB_PLUGIN_DIR . 'templates/admin/settings-page.php';
	}
}
