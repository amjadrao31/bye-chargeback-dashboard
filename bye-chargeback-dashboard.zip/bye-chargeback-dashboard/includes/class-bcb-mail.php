<?php
/**
 * Branded transactional email delivery.
 *
 * @package ByeChargeBack
 */

defined( 'ABSPATH' ) || exit;

/**
 * HTML sign-in and notification emails.
 */
class BCB_Mail {

	/**
	 * Register mail filters once.
	 */
	public static function init() {
		add_filter( 'wp_mail_from', array( __CLASS__, 'filter_from_email' ) );
		add_filter( 'wp_mail_from_name', array( __CLASS__, 'filter_from_name' ) );
		add_filter( 'wp_mail_content_type', array( __CLASS__, 'filter_content_type' ) );
		add_action( 'phpmailer_init', array( __CLASS__, 'configure_local_smtp' ) );
	}

	/**
	 * Route mail through Local WP MailHog when running locally.
	 *
	 * @param PHPMailer $phpmailer Mailer instance.
	 */
	public static function configure_local_smtp( $phpmailer ) {
		if ( ! self::$sending || 'local' !== wp_get_environment_type() ) {
			return;
		}

		$phpmailer->isSMTP();
		$phpmailer->Host       = '127.0.0.1';
		$phpmailer->Port       = 1025;
		$phpmailer->SMTPAuth   = false;
		$phpmailer->SMTPSecure = false;
	}

	/**
	 * From address for plugin emails.
	 *
	 * @param string $email Default from email.
	 * @return string
	 */
	public static function filter_from_email( $email ) {
		if ( ! self::$sending ) {
			return $email;
		}

		$settings = BCB_Settings::all();
		$candidate = sanitize_email( $settings['brand_email'] );

		if ( is_email( $candidate ) ) {
			return $candidate;
		}

		return sanitize_email( get_option( 'admin_email', $email ) );
	}

	/**
	 * From name for plugin emails.
	 *
	 * @param string $name Default from name.
	 * @return string
	 */
	public static function filter_from_name( $name ) {
		if ( ! self::$sending ) {
			return $name;
		}

		return BCB_Settings::get( 'brand_name', 'ByeChargeBack' );
	}

	/**
	 * HTML content type while sending plugin mail.
	 *
	 * @param string $type Default type.
	 * @return string
	 */
	public static function filter_content_type( $type ) {
		if ( ! self::$sending ) {
			return $type;
		}

		return 'text/html';
	}

	/**
	 * Whether a plugin email is currently being sent.
	 *
	 * @var bool
	 */
	private static $sending = false;

	/**
	 * Send sign-in email with button, credentials, and CTA.
	 *
	 * @param WP_User $user     User account.
	 * @param string  $password Plain-text password to include.
	 * @param bool    $is_new   Whether the account was just created.
	 * @return bool
	 */
	public static function send_sign_in_email( WP_User $user, $password, $is_new ) {
		$settings    = BCB_Settings::all();
		$brand       = $settings['brand_name'];
		$sign_in_url = BCB_Frontend::get_sign_in_page_url();
		$subject     = sprintf(
			/* translators: %s: brand name */
			__( '%s — Sign in to your account', 'bye-chargeback-dashboard' ),
			$brand
		);

		$intro = $is_new
			? sprintf(
				/* translators: %s: brand name */
				__( 'Welcome to %s. Your account is ready.', 'bye-chargeback-dashboard' ),
				esc_html( $brand )
			)
			: __( 'Use the details below to sign in to your dashboard.', 'bye-chargeback-dashboard' );

		$message = self::render_template(
			array(
				'brand'       => $brand,
				'intro'       => $intro,
				'sign_in_url' => $sign_in_url,
				'email'       => $user->user_email,
				'password'    => $password,
				'support'     => $settings['brand_email'],
			)
		);

		self::$sending = true;
		$sent          = wp_mail(
			$user->user_email,
			$subject,
			$message,
			array(
				'Reply-To: ' . sanitize_email( $settings['brand_email'] ),
			)
		);
		self::$sending = false;

		if ( ! $sent ) {
			self::log_failure( $user->user_email, $subject );
		}

		return $sent;
	}

	/**
	 * HTML email layout.
	 *
	 * @param array $data Template data.
	 * @return string
	 */
	private static function render_template( array $data ) {
		$brand       = esc_html( $data['brand'] );
		$intro       = esc_html( $data['intro'] );
		$sign_in_url = esc_url( $data['sign_in_url'] );
		$email       = esc_html( $data['email'] );
		$password    = esc_html( $data['password'] );
		$support     = esc_html( $data['support'] );

		ob_start();
		?>
		<!DOCTYPE html>
		<html>
		<head>
			<meta charset="UTF-8">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link href="https://fonts.googleapis.com/css2?family=Gabarito:wght@400;600;700&display=swap" rel="stylesheet">
		</head>
		<body style="margin:0;padding:0;background:#eef4ed;font-family:Gabarito,Arial,sans-serif;color:#0b2545;">
			<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#eef4ed;padding:32px 16px;">
				<tr>
					<td align="center">
						<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border-radius:20px;overflow:hidden;box-shadow:0 20px 50px rgba(11,37,69,0.12);border:1px solid rgba(141,169,196,0.45);">
							<tr>
								<td style="padding:32px 32px 16px;text-align:center;">
									<div style="font-size:28px;font-weight:700;color:#134074;"><?php echo $brand; ?></div>
								</td>
							</tr>
							<tr>
								<td style="padding:0 32px 8px;text-align:center;font-size:18px;font-weight:600;line-height:1.5;color:#0b2545;">
									<?php echo $intro; ?>
								</td>
							</tr>
							<tr>
								<td style="padding:8px 32px 24px;text-align:center;">
									<a href="<?php echo $sign_in_url; ?>" style="display:inline-block;background:#134074;color:#ffffff;text-decoration:none;font-weight:700;padding:14px 28px;border-radius:12px;font-size:16px;">
										<?php echo esc_html__( 'Sign in', 'bye-chargeback-dashboard' ); ?>
									</a>
								</td>
							</tr>
							<tr>
								<td style="padding:0 32px 24px;">
									<table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="background:#eef4ed;border:1px solid rgba(141,169,196,0.45);border-radius:14px;">
										<tr>
											<td style="padding:18px 20px;font-size:14px;line-height:1.6;">
												<strong><?php echo esc_html__( 'Email:', 'bye-chargeback-dashboard' ); ?></strong> <?php echo $email; ?><br>
												<strong><?php echo esc_html__( 'Password:', 'bye-chargeback-dashboard' ); ?></strong> <?php echo $password; ?>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr>
								<td style="padding:0 32px 32px;text-align:center;font-size:13px;color:#6b7280;line-height:1.6;">
									<?php
									printf(
										/* translators: %s: support email */
										esc_html__( 'Need help? Contact us at %s', 'bye-chargeback-dashboard' ),
										esc_html( $support )
									);
									?>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</body>
		</html>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Log failed delivery for local debugging.
	 *
	 * @param string $to      Recipient.
	 * @param string $subject Subject line.
	 */
	private static function log_failure( $to, $subject ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( sprintf( 'BCB mail failed: to=%s subject=%s', $to, $subject ) );
		}
	}

	/**
	 * Local/dev helper text when mail fails.
	 *
	 * @return string
	 */
	public static function get_failure_hint() {
		return __( 'We could not send the email from this server. On Local, open MailHog in the Local app to view outgoing mail, or install an SMTP plugin for production.', 'bye-chargeback-dashboard' );
	}
}
